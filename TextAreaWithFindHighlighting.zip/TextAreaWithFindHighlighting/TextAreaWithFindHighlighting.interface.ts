export type Props = {
  wordsToHighlight: string[];
  isCaseSensitive: boolean;
  textAreaFormDataName: string;
  useRegularExpression: boolean;
};
