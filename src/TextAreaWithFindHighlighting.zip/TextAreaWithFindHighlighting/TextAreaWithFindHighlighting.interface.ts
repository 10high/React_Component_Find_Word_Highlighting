export type Props = {
  wordToHighlight: string;
  isCaseSensitive: boolean;
  textAreaFormDataName: string;
  useRegularExpression: boolean;
};
